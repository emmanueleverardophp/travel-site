# example.js

``` javascript
_{{example.js}}_
```

# dist/output.js

``` javascript
_{{dist/output.js}}_
```

# dist/577.output.js

``` javascript
_{{dist/577.output.js}}_
```

# Info

## Unoptimized

```
_{{stdout}}_
```

## Production mode

```
_{{production:stdout}}_
```

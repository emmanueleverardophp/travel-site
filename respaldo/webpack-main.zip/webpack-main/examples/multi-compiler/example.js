if(ENV === "mobile") {
	require("./mobile-stuff");
}
console.log("Running " + ENV + " build");
# example.js

```javascript
_{{example.js}}_
```

# webpack.config.js

```javascript
_{{webpack.config.js}}_
```

# dist/desktop.js

```javascript
_{{dist/desktop.js}}_
```

# dist/mobile.js

```javascript
_{{dist/mobile.js}}_
```

# Info

## Unoptimized

```
_{{stdout}}_
```

## Production mode

```
_{{production:stdout}}_
```

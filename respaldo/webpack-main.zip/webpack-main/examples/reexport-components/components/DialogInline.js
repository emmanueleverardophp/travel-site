const DialogInline = ({ children }) => {
	return <dialog>{children}</dialog>;
};
export { DialogInline };

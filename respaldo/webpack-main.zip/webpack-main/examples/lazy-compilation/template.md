To run this example you need to install `webpack-dev-server` and run `webpack serve`.

# example.js

```javascript
_{{example.js}}_
```

# webpack.config.js

```javascript
_{{webpack.config.js}}_
```

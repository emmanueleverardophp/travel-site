# example.js

```javascript
_{{example.js}}_
```

# increment.js

```javascript
_{{increment.js}}_
```

# dist/output.js

```javascript
_{{dist/output.js}}_
```

# Info

## Unoptimized

```
_{{stdout}}_
```

## Production mode

```
_{{production:stdout}}_
```

module.exports = {
	output: {
		uniqueName: "app"
	},
	experiments: {
		css: true
	}
};

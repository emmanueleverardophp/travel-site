This example shows the usage of the asset module type with asset generator options customization.

Files can be imported similar to other modules without file-loader or url-loader.

# example.js

```javascript
_{{example.js}}_
```

# webpack.config.js

```javascript
_{{webpack.config.js}}_
```

# js/output.js

```javascript
_{{dist/output.js}}_
```

# Info

## webpack output

```
_{{stdout}}_
```
